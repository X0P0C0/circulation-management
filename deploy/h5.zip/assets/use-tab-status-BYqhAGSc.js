import{aX as l,ay as o,z as u}from"./index-CukzJDhz.js";const e=Symbol(),s=Symbol(),n=()=>l(s,null),T=a=>{const t=n();o(e,a),o(s,u(()=>(t==null||t.value)&&a.value))};export{T as a,n as u};
