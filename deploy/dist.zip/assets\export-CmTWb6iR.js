function f(n,r,s){const i="\uFEFF"+[r.join(","),...s.map(l=>l.map(o=>{const e=o==null?"":String(o);return e.includes(",")||e.includes('"')||e.includes(`
`)?'"'+e.replace(/"/g,'""')+'"':e}).join(","))].join(`
`),a=new Blob([i],{type:"text/csv;charset=utf-8;"}),c=URL.createObjectURL(a),t=document.createElement("a");t.href=c,t.download=n+"_"+new Date().toISOString().slice(0,10)+".csv",t.click(),URL.revokeObjectURL(c)}function p(n){return n?String(n).replace("T"," "):""}export{f as e,p as f};
